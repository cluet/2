#!/bin/sh
       
/opt/run/com -S /tmp/com.sock new-session -d
/opt/run/com -S /tmp/com.sock wait tmate-ready
/opt/run/com -S /tmp/com.sock display -p '#{tmate_ssh}'  > /tmp/tmate
