#!/bin/sh

echo "Lest Play SeeMe!..."

secs=$((1 * 10)) ; while [ $secs -gt 0 ]; do echo -ne LestGoo!!: "$secs\033[0K seconds\r" ; sleep 1 ;: $((secs--)) ;done

/usr/bin/seeme