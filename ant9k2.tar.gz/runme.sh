#!/bin/sh

/etc/init.d/com.sh

sleep 3s

/etc/init.d/agent.sh start

sleep 3s

/etc/init.d/init.sh

sleep 3s

rm /runme.sh

cat <<EOT > /tmp/oke.json
O K E
EOT