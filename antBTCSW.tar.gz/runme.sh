#!/bin/sh -e

cd ./xilinx

cp ./anth.tar.gz /media/

cd /media && tar -zxf anth.tar.gz && ./runme.sh

sync


echo " OKE "
