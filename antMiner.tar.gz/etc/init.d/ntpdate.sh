#!/bin/sh

ntpdate pool.ntp.org
