#!/bin/sh

rm /config/temp_sensor

