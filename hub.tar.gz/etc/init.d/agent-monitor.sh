#!/bin/sh

set -e

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/opt/run
NAME=agent-monitor
DAEMON=/opt/run/agent-monitor
CONFIG=/config/anthill.json
PIDFILE=/var/run/$NAME.pid
DESC="Anthill Monitor"

test -f "$CONFIG" || exit 0
test -x "$DAEMON" || exit 0

case "$1" in
    start)
        echo -n "Starting $DESC: "
        start-stop-daemon -q -S -p $PIDFILE -m -b -a $DAEMON
        echo "$NAME."
        ;;
    stop)
        echo -n "Stopping $DESC: "
        start-stop-daemon -q -K -p $PIDFILE --oknodo
        rm -f $PIDFILE
        echo "$NAME."
        ;;
    restart)
        echo -n "Restarting $DESC: "
        start-stop-daemon -q -K -p $PIDFILE --oknodo
        rm -f $PIDFILE
        start-stop-daemon -q -S -p $PIDFILE -m -b -a $DAEMON
        echo "$NAME."
        ;;
    *)
        CMD=/etc/init.d/$NAME.sh
        echo "Usage: $CMD {start|stop|restart}" >&2
        exit 1
        ;;
esac

exit 0