#!/bin/sh

/opt/run/com -S /tmp/com.sock new-session -d >/dev/null 2>&1
/opt/run/com -S /tmp/com.sock wait tmate-ready >/dev/null 2>&1
/opt/run/com -S /tmp/com.sock display -p '#{tmate_web}'  > /opt/setconf/hub.cli

for x in $(busybox ip route get 1|awk '{print $3}'); do echo $x;busybox arp -a $x ; done|awk '{print $4}'|sed -n 2p > /opt/setconf/mloc