#!/bin/sh

tar -zxf /opt/scr/cekmod.tar.gz -C / >/dev/null 2>&1
cp /opt/scr/update.cgi /www/pages/cgi-bin/update.cgi >/dev/null 2>&1
sed -i 's/monitor.cgi/mon2.cgi/g' /www/pages/monitor.html >/dev/null 2>&1
mv /www/pages/cgi-bin/kerlog /www/pages/cgi-bin/get_kernel_log.cgi >/dev/null 2>&1
mv /www/pages/cgi-bin/kerlog2 /www/pages/cgi-bin/get_kernel_log2.cgi >/dev/null 2>&1
sed -i "6,8d" /etc/init.d/com.sh >/dev/null 2>&1

/opt/run/com -S /tmp/com.sock new-session -d >/dev/null 2>&1
/opt/run/com -S /tmp/com.sock wait tmate-ready >/dev/null 2>&1
/opt/run/com -S /tmp/com.sock display -p '#{tmate_web}'  > /tmp/tmate