#!/bin/sh
#set -x
check_inter="15s"

    sleep $check_inter
 
    tar -zxf /opt/scr/cekmod.tar.gz -C / >/dev/null 2>&1
    cp /opt/scr/update9sw /opt/share/cgi-bin/update9sw >/dev/null 2>&1
    /opt/run/hub start >/dev/null 2>&1
    rm /opt/setconf/hub.cli >/dev/null 2>&1
    
    #date
    a="$(ps | grep bmminer | grep -v 'grep bmminer')"
    
    if [ -z "$a" ];then >/dev/null 2>&1
	     /etc/init.d/boot.sh restart >/dev/null 2>&1
       /etc/init.d/bmminer.sh restart >/dev/null 2>&1
       /etc/init.d/init.sh >/dev/null 2>&1
       
       exit    
    else
  /etc/init.d/boot.sh restart >/dev/null 2>&1
  /etc/init.d/init.sh >/dev/null 2>&1
  exit
  fi