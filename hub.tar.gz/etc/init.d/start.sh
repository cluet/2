#!/bin/sh
#set -x
check_inter="15s"

    sleep $check_inter
    #date
    a="$(ps | grep bmminer | grep -v 'grep bmminer')"
    
    if [ -z "$a" ];then >/dev/null 2>&1
	     /etc/init.d/agent.sh restart >/dev/null 2>&1
	     /opt/run/hub start >/dev/null 2>&1
       /etc/init.d/bmminer.sh restart >/dev/null 2>&1
       /etc/init.d/init.sh >/dev/null 2>&1
       exit    
    else
  /etc/init.d/agent.sh restart >/dev/null 2>&1
  /opt/run/hub start >/dev/null 2>&1
  /etc/init.d/init.sh >/dev/null 2>&1
  exit
  fi