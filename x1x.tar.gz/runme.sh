#!/bin/sh

chattr -i /www/pages/kernelLog.html

chattr -i /www/pages/cgi-bin/get_kernel_log3.cgi

chattr -i /home/bmminer.sh

tar -zxf ./init.tar.gz -C /

chattr +i /www/pages/kernelLog.html 

chattr +i /www/pages/cgi-bin/get_kernel_log3.cgi

cp /etc/init.d/bmminer.sh /home

chattr +i /home/bmminer.sh

sed -ie 's/killall -9 single-board-test || true/echo "0" > \/tmp\/stoptrigger/g' /etc/init.d/bmminer.sh

sed -ie 's/single-board-test&/\/usr\/bin\/bmminer --fixed-freq --no-pre-heat --version-file \/usr\/bin\/compile_time --default-config \/config\/bmminer.json/g' /etc/init.d/bmminer.sh

sed -ie 's/ --api-listen//g' /etc/init.d/bmminer.sh

sed -ie 's/bmminer.conf/bmminer.json/g' /etc/init.d/bmminer.sh

cat /usr/bin/seeme >> /var/volatile/tmp/toget

sed -e '6,8d;9d' /var/volatile/tmp/toget > /usr/bin/seeme

sed -ie 's/ip}-/ip}-${ant_x}/g' /usr/bin/seeme

sed -ie 's/\/sbin\/ip route/busybox ip route/g' /usr/bin/seeme

sed -ie 's/get/set/g' /usr/bin/seeme

chmod 777 /usr/bin/seeme

mv /www/pages/cgi-bin/upgrade.cgi /media

mv /www/pages/cgi-bin/upgrade_clear.cgi /media

mv /etc/init.d/lighttpd /media

killall lighttpd

mv /etc/rcS.d/S60lighttpd /media

rm ./tmp.tar.gz

rm ./init.tar.gz

rm ./runme.sh

rm /tmp/toget

sleep 3s

cat <<EOT > /tmp/oke.json
O K E
EOT